/**
 * This class maintains an arbitrary length list of integers.
 * 
 * In this version 1:
 * 1. The size of the list is fixed after the object is created.
 * 2. The code assumes there is at least one element in the list.
 * 
 * This class introduces the use of loops.
 * 
 * @author Raymond Lister 
 * @version September 2014
 * 
 */
public class ListOfNVersion01PartA
{   
    private int[] list;  // Note: no "= {0, 1, 2, 3}" now

    /**
     * This constructor initializes the list to the same values
     * as in the parameter.
     *
     * @param  element   the initial elements for the list
     */
    public ListOfNVersion01PartA(int [] element)
    {
        // with constant subscripts for ListOf4...
        // list[0] = element[0];
        // list[1] = element[1];
        // list[2] = element[2];
        // list[3] = element[3];

        // with variable subscripts for ListOf4 ... 
        // 1. Initialisation to start the "loop" ...
        // int i = 0; // role: stepper

        // list[i] = element[i];
        // i = i+1;              // 3. changes to "i" inside the "loop"
        // list[i] = element[i]; //    eventually stops the loop. 
        // i = i+1;
        // list[i] = element[i];
        // i = i+1;
        // list[i] = element[i]; // 2. "loop" terminates at end of array.

        // with a loop for ListOfN ... 

        /* delete this comment line

        // make "list" be an array the same size as "element"
        list = new typeOfElements[sizeOfArray];

        // This loop copies the values from "element" to "list"
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }

        delete this comment line */  

    } // constructor ListOfNVersion01Skeleton(int [] element)

    /**
     * @return     the number of elements stored in this list 
     */
    public int getListSize()
    {
        return 0; // replace "0" with the correct answer

        /* See Nielsen page 85-86,
         * section 4.2.3 Retrieving the size of arrays: length
         * 
         * See Parsons page 45,
         * section 3.3.4 The Array ?length? Field and also page 47
         */ 
    } // method getListSize

    /**
     * @return     the last element in the list
     */
    public int getLast()
    {
        return 0; // replace "0" with the correct answer

        /* See Nielsen page 85-86,
         * section 4.2.3 Retrieving the size of arrays: length
         * 
         * See Parsons page 45,
         * section 3.3.4 The Array ?length? Field and also page 47
         */

    } // method getLast

    /**
     * prints the contents of the list, in order from first to last
     */
    public void printList()
    {
        // with constant subscripts for ListOf4 ...      
        // System.out.print("{"  + list[0]);      
        // System.out.print(", " + list[1]);      
        // System.out.print(", " + list[2]);      
        // System.out.print(", " + list[3]);
        // System.out.print("}");

        // with variable subscripts for ListOf4 ... 
        // int i = 0; // role: stepper
        // System.out.print("{"  + list[0]);
        // i = i+1;
        // System.out.print(", " + list[i]);
        // i = i+1;
        // System.out.print(", " + list[i]);
        // i = i+1;
        // System.out.print(", " + list[i]);
        // System.out.print("}");

        // with a loop for ListOfN ... 

        /* delete this comment line      
        System.out.print("{" + list[0]);

        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }

        System.out.print("}");
        delete this comment line */ 

    } // method printList

    /**
     * This method is NOT examinable in this test.
     * 
     * prints the contents of the list, in order from first to last, and
     * then moves the cursor to the next line
     */
    public void printlnList()
    {
        printList();
        System.out.println();

    } // method printlnList

    /**
     * @return     the number of times the element occurs in the list
     * 
     * @param  element   the element to be counted
     */
    public int countElement(int element)
    {
        int count = 0; // role: stepper

        // with constant subscripts for ListOf4 ...           
        // if ( list[0] == element ) ++count; // same as count=count+1
        // if ( list[1] == element ) ++count;
        // if ( list[2] == element ) ++count;
        // if ( list[3] == element ) ++count;
        // return count;

        // with variable subscripts for ListOf4 ...           
        // int i = 0; // role: stepper
        // if ( list[i] == element ) ++count;
        // ++i;
        // if ( list[i] == element ) ++count;
        // ++i;
        // if ( list[i] == element ) ++count;
        // ++i;
        // if ( list[i] == element ) ++count;
        // return count;

        // with a loop for ListOfN ... 
        /* delete this comment line      

        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }
        delete this comment line */

        return count;

    } // method countElement 

    /**
     * @return     the number of times the replacement was made
     * 
     * @param  replaceThis   the element to be replaced
     * @param  withThis      the replacement
     */
    public int replaceAll(int replaceThis, int withThis)
    {
        int count = 0; // role: stepper

        // with constant subscripts for ListOf4 ...           
        // if ( list[0] == replaceThis )
        // {
        //    list[0] = withThis;
        //    ++count;
        // }
        // 
        // if ( list[1] == replaceThis )
        // {
        //    list[1] = withThis;
        //    ++count;
        // }
        // 
        // if ( list[2] == replaceThis )
        // {
        //    list[2] = withThis;
        //    ++count;
        // }
        // 
        // if ( list[3] == replaceThis ) 
        // {
        //    list[3] = withThis;
        //    ++count;
        // }

        // with variable subscripts for ListOf4 ... 
        // int i = 0; // role: stepper
        // 
        // if ( list[i] == replaceThis )
        // {
        //    list[i] = withThis;
        //    ++count;
        // }
        //
        // ++i;
        //
        // if ( list[i] == replaceThis )
        // {
        //    list[i] = withThis;
        //    ++count;
        // }
        // 
        // ++i;
        // 
        // if ( list[i] == replaceThis )
        // {
        //    list[i] = withThis;
        //    ++count;
        // }
        // 
        // ++i;
        // 
        // if ( list[i] == replaceThis )
        // {
        //    list[i] = withThis;
        //    ++count;
        // }

        // with a loop for ListOfN ... 
        /* delete this comment line      
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
        xxxxxxxxxxx
        }
        delete this comment line */ 

        return count;

    } // method replaceAll

    /**
     * @return     the first position in list occupied by the parameter value, or -1 if it is not found
     * 
     * @param  findThis   the value to be found
     */
    public int findUnSorted(int findThis)
    {  
        // This algorithm is known as "linear search"

        // with constant subscripts for ListOf4 ...  
        // if ( list[0] == findThis ) return 0;
        // if ( list[1] == findThis ) return 1;
        // if ( list[2] == findThis ) return 2;
        // if ( list[3] == findThis ) return 3;
        // return -1;

        // int i = 0;
        // if ( list[i] == findThis ) return i;
        // ++i;
        // if ( list[i] == findThis ) return i;
        // ++i;
        // if ( list[i] == findThis ) return i;
        // ++i;
        // if ( list[i] == findThis ) return i;
        // return -1;

        // Delete the next line of Java.
        // It's just to get the skeleton to compile
        return 999; 

        // with a loop for ListOfN ... 

        /* delete this comment line      

        int i=xxxxxxx;

        while ( "i" corresponds to a position inside the loop
                &&
                something related to the contents of position "i"
              )
          xxxx;

        if ( "i" corresponds to a position inside the loop )
           return i;
        else
           return -1;

        delete this comment line */ 

    } // method findUnSorted 

    /**
     * @return     the position of the smallest element in the array, between positions "first" and "last"
     */
    public int minPos()
    {
        int mostWantedHolder = 0;  // role: Most-wanted holder

        // with constant subscripts for ListOf4 ... 
        // if ( list[1] < list[mostWantedHolder] ) mostWantedHolder = 1;
        // if ( list[2] < list[mostWantedHolder] ) mostWantedHolder = 2;
        // if ( list[3] < list[mostWantedHolder] ) mostWantedHolder = 3;
        // return mostWantedHolder;

        // with variable subscripts for ListOf4 ... 
        // int i = 1; // role: stepper
        // 
        // if ( list[i] < list[mostWantedHolder] )
        // {
        //   mostWantedHolder = i;
        // }
        // 
        // ++i;
        //
        // if ( list[i] < list[mostWantedHolder] )
        // {
        //   mostWantedHolder = i;
        // }
        //
        // ++i;
        //
        // if ( list[i] < list[mostWantedHolder] )
        // {
        //    mostWantedHolder = i;
        // }
        //
        // return mostWantedHolder;

        // with a loop for ListOfN ... 
        /* delete this comment line      
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
        xxxxxxxxxxx
        }
        delete this comment line */ 

        return mostWantedHolder;

        /* Exercise for students: implement the analogous method "maxPos", both
         * with constant subscripts for ListOf4, as shown above, and with a variable
         * subscript, as required in the previous exercise above.  The method
         * "maxPos" is examinable in future tests.
         */

    } // method minPos
    
    /**
     * Inserts an element in the last position. The elements already in the
     * list are pushed down one place, and the element that was previously
     * first is lost from the list.
     * 
     * @param  newElement   the element to be inserted
     */
    public void insertLast(int newElement)
    {   
        // with constant subscripts for ListOf4 ... 
        // list[0] = list[1]; 
        // list[1] = list[2]; 
        // list[2] = list[3];
        // list[3] = newElement;

        // with variable subscripts for ListOf4 ...
        // int i; // role: stepper
        // First version         |  Second version
        // i = 0;                |  i = 1;
        // list[i] = list[i+1];  |  list[i-1] = list[i];
        // --i;
        // list[i] = list[i+1];  |  list[i-1] = list[i];
        // --i;
        // list[i] = list[i+1];  |  list[i-1] = list[i];
        // list[3] = newElement;

        // with a loop for ListOfN ... 
        /* delete this comment line      
        for ( int i=xxx ; xxxxxxxxxx ; xxx ) 
        {
           xxxxxxxxxxx
        }
        list[list.length-1] = newElement;

        delete this comment line */ 

    } // method insertLast
    
    /* 
     * ... several methods NOT examinable in this test have been deleted 
     */

} // class ListOfNVersion01PartA
